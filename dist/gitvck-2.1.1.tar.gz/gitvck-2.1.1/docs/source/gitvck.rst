======
gitvck
======

.. automodule:: gitvck
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

